package com.example.imc_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
