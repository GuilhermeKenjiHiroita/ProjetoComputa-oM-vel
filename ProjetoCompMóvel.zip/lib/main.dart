import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BMICalculator(),
    );
  }
}

class BMICalculator extends StatefulWidget {
  @override
  _BMICalculatorState createState() => _BMICalculatorState();
}

class _BMICalculatorState extends State<BMICalculator> {
  TextEditingController txtAgeController = TextEditingController();
  TextEditingController txtWeightController = TextEditingController();
  TextEditingController txtHeightController = TextEditingController();
  TextEditingController txtInchesController = TextEditingController();
  TextEditingController txtResultController = TextEditingController();

  String? selectedMeasurement = "Metric";
  bool isFemale = false;
  bool isMale = false;
  bool isKilogram = false;
  bool isPound = false;
  bool isCentimeter = false;
  bool isFeet = false;

  @override
  void initState() {
    super.initState();
    selectedMeasurement = "Metric";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButton<String>(
                value: selectedMeasurement,
                onChanged: (String? value) {
                  setState(() {
                    selectedMeasurement = value;
                  });
                },
                items: <String>['Imperial', 'Metric'].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              TextField(
                controller: txtAgeController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Age'),
              ),
              TextField(
                controller: txtWeightController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Weight'),
              ),
              TextField(
                controller: txtHeightController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Height'),
              ),
              Visibility(
                visible: selectedMeasurement == 'Imperial',
                child: TextField(
                  controller: txtInchesController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: 'Inches'),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Text('Gender'),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isFemale,
                            onChanged: (bool? value) {
                              setState(() {
                                isFemale = value!;
                                isMale = !value;
                              });
                            },
                          ),
                          Text('Female'),
                        ],
                      ),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isMale,
                            onChanged: (bool? value) {
                              setState(() {
                                isMale = value!;
                                isFemale = !value;
                              });
                            },
                          ),
                          Text('Male'),
                        ],
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Text('Weight'),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isKilogram,
                            onChanged: (bool? value) {
                              setState(() {
                                isKilogram = value!;
                                isPound = !value;
                              });
                            },
                          ),
                          Text('Kilogram'),
                        ],
                      ),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isPound,
                            onChanged: (bool? value) {
                              setState(() {
                                isPound = value!;
                                isKilogram = !value;
                              });
                            },
                          ),
                          Text('Pound'),
                        ],
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Text('Height'),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isCentimeter,
                            onChanged: (bool? value) {
                              setState(() {
                                isCentimeter = value!;
                                isFeet = !value;
                              });
                            },
                          ),
                          Text('Centimeter'),
                        ],
                      ),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isFeet,
                            onChanged: (bool? value) {
                              setState(() {
                                isFeet = value!;
                                isCentimeter = !value;
                              });
                            },
                          ),
                          Text('Feet'),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              ElevatedButton(
                onPressed: () => calculateBMI(selectedMeasurement),
                child: Text('Calculate'),
              ),
              TextField(
                controller: txtResultController,
                keyboardType: TextInputType.multiline,
                maxLines: null,
                readOnly: true,
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: clearFields,
        tooltip: 'Clear',
        child: Icon(Icons.clear),
      ),
    );
  }

  void clearFields() {
    txtAgeController.clear();
    txtWeightController.clear();
    txtHeightController.clear();
    txtInchesController.clear();
    txtResultController.clear();
    setState(() {
      isFemale = false;
      isMale = false;
      isKilogram = false;
      isPound = false;
      isCentimeter = false;
      isFeet = false;
    });
  }

  void calculateBMI(String? measurement) {
    // Add your BMI calculation logic here
    double weight = double.parse(txtWeightController.text);
    double height = double.parse(txtHeightController.text);
    double resultBMI = 0;
    double resultBMR = 0;
    int age = int.parse(txtAgeController.text);

    if (measurement == 'Imperial') {
      int inches = int.parse(txtInchesController.text);
      double heightInches = (height * 12) + inches;
      double heightCM = heightInches * 2.54;
      double weightKG = weight / 2.2;

      if (isFemale && isPound && isFeet) {
        resultBMI = (weight / (heightInches * heightInches)) * 703;
        resultBMR =
            447.593 + (9.247 * weightKG) + (3.098 * heightCM) - (4.330 * age);
      } else if (isMale && isPound && isFeet) {
        resultBMI = (weight / (heightInches * heightInches)) * 703;
        resultBMR =
            88.362 + (13.397 * weightKG) + (4.799 * heightCM) - (5.677 * age);
      }
    } else if (measurement == 'Metric') {
      if (isFemale && isKilogram && isCentimeter) {
        resultBMI = weight / (height * height);
        resultBMR = 447.593 +
            (9.247 * weight) +
            (3.098 * (height * 100)) -
            (4.330 * age);
      } else if (isMale && isKilogram && isCentimeter) {
        resultBMI = weight / (height * height);
        resultBMR = 88.362 +
            (13.397 * weight) +
            (4.799 * (height * 100)) -
            (5.677 * age);
      }
    }

    String BMIResult;

    if (resultBMI < 16.0) {
      BMIResult = "Severely Underweight";
    } else if (resultBMI >= 16.0 && resultBMI < 18.5) {
      BMIResult = "Underweight";
    } else if (resultBMI >= 18.5 && resultBMI < 25.0) {
      BMIResult = "Normal";
    } else if (resultBMI >= 25.0 && resultBMI < 30.0) {
      BMIResult = "Overweight";
    } else if (resultBMI >= 30.0 && resultBMI < 35.0) {
      BMIResult = "Moderately Obese";
    } else if (resultBMI >= 35.0 && resultBMI < 40.0) {
      BMIResult = "Severely Obese";
    } else {
      BMIResult = "Morbidly Obese";
    }

    txtResultController.text =
        "Your BMI is: ${resultBMI.toStringAsFixed(2)}\n" +
            "Category: $BMIResult\n" +
            "Your metabolic rate is: ${resultBMR.toStringAsFixed(2)}";
  }
}
